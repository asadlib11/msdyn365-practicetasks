[//]: # (How to update this markdown document)
[//]: # (add a new line above the most recent version)
[//]: # (add the new version and what you added)
[//]: # (this ensures we avoid merge conflicts in package.json)

* 1.0.66 Update app settings to add default suggestion types for auto suggest
* 1.0.64 remove BS classes from navigation menu.
* 1.0.63 Fixing LCS validation issue.
* 1.0.62 Fixing theme for autosuggest and cookie.
* 1.0.61 Address update.
* 1.0.59 Header theme fix.
* 1.0.53 Version update.
* 1.0.49 Adding cookie-cmpliance styles
* 1.0.48 Fixing content placement width issue
* 1.0.47 Updating image settings for modules with CMS images
* 1.0.46 Use image settings in Autosuggest, Cart, Checkout, Content placement, Footer, Logo, Order-details, Order-history and wishlist
* 1.0.45 Fixed the visuality of Footer section links on keyboard focus
* 1.0.43 Use image settings in Hero, feature and Product Placement modules
* 1.0.43 Fixed focus issue for product placement item
* 1.0.41 Alert css changes
* 1.0.40 Added padding right to address css.
* 1.0.39 Footer accessibility fixe
* 1.0.38 buybox fixes
* 1.0.37 Btn high-contrast changes.
* 1.0.36 Footer changes
* 1.0.35 Accordion font awesome changes
* 1.0.34 Fixing IE11 bug
* 1.0.33 Cart CSS
* 1.0.32 Icon validation fix 
* 1.0.31 Package version update for fabrikam deployment
* 1.0.30 Package version update for fabrikam deployment
* 1.0.29 Design feedback implentation for content rich block
* 1.0.28 Minor fixes
* 1.0.25 Latest verrsion update
* 1.0.24 Mobile header fix
* 1.0.22 Minor header fix.
* 1.0.21 Accordion css changes.
* 1.0.16 Updats in theme and bumped theme version to 1.0.16
* 1.0.9 Updats in theme and bumped theme version to 1.0.5