/**
 * Copyright (c) 2018 Microsoft Corporation
 * ITextPage contentModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';

export interface ITextPageConfig extends Msdyn365.IModuleConfig {
    showText?: string;
}

export interface ITextPageResources {
    resourceKey: string;
}

export interface ITextPageProps<T> extends Msdyn365.IModule<T> {
    resources: ITextPageResources;
    config: ITextPageConfig;
}
