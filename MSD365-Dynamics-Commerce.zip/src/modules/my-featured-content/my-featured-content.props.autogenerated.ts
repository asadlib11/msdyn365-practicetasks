/**
 * Copyright (c) 2018 Microsoft Corporation
 * IMyFeaturedContent contentModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';

export const enum imageAlignment {
    left = 'left',
    right = 'right'
}

export interface IMyFeaturedContentConfig extends Msdyn365.IModuleConfig {
    showText?: string;
    imageAlignment?: imageAlignment;
    imageSrc: string;
    productIds?: string;
}

export interface IMyFeaturedContentResources {
    resourceKey: string;
}

export interface IMyFeaturedContentProps<T> extends Msdyn365.IModule<T> {
    resources: IMyFeaturedContentResources;
    config: IMyFeaturedContentConfig;
}
