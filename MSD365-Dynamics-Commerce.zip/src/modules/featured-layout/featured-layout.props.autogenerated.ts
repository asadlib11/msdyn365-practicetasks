/**
 * Copyright (c) 2018 Microsoft Corporation
 * IFeaturedLayout containerModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';
import * as React from 'react';

export interface IFeaturedLayoutConfig extends Msdyn365.IModuleConfig {
    className?: string;
}

export interface IFeaturedLayoutResources {
    resourceKey: string;
}

export interface IFeaturedLayoutProps<T> extends Msdyn365.IModule<T> {
    resources: IFeaturedLayoutResources;
    config: IFeaturedLayoutConfig;
    slots: {
        leftItem: React.ReactNode[];
        rightTopLeftItem: React.ReactNode[];
        rightTopRightItem: React.ReactNode[];
        rightBaseItem: React.ReactNode[];
    };
}
