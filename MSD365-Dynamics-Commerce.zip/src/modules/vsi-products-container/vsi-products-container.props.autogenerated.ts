/**
 * Copyright (c) 2018 Microsoft Corporation
 * IVsiProductsContainer containerModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';
import * as React from 'react';

export interface IVsiProductsContainerProps<T> extends Msdyn365.IModule<T> {
    slots: {
        content: React.ReactNode[];
    };
}
