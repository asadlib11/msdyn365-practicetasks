/**
 * Copyright (c) 2018 Microsoft Corporation
 * IFeaturedCategory contentModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';

export interface IFeaturedCategoryConfig extends Msdyn365.IModuleConfig {
    categoryLink: ICategoryLinkData;
    buttonText: string;
    categoryImage: string;
}

export interface IFeaturedCategoryResources {
    resourceKey: string;
}

export interface ICategoryLinkData {
    linkText?: string;
    linkUrl: Msdyn365.ILinkData;
    ariaLabel?: string;
    openInNewTab?: boolean;
}

export interface IFeaturedCategoryProps<T> extends Msdyn365.IModule<T> {
    resources: IFeaturedCategoryResources;
    config: IFeaturedCategoryConfig;
}
