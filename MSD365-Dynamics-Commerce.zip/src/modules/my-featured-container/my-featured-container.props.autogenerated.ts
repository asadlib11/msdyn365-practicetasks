/**
 * Copyright (c) 2018 Microsoft Corporation
 * IMyFeaturedContainer containerModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';
import * as React from 'react';

export interface IMyFeaturedContainerConfig extends Msdyn365.IModuleConfig {
    showText?: string;
}

export interface IMyFeaturedContainerResources {
    resourceKey: string;
}

export interface IMyFeaturedContainerProps<T> extends Msdyn365.IModule<T> {
    resources: IMyFeaturedContainerResources;
    config: IMyFeaturedContainerConfig;
    slots: {
        slot1: React.ReactNode[];
        slot2: React.ReactNode[];
    };
}
