/**
 * Copyright (c) 2018 Microsoft Corporation
 * IFeaturedLayoutItem contentModule Interface Properties
 * THIS FILE IS AUTO-GENERATED - MANUAL MODIFICATIONS WILL BE LOST
 */

import * as Msdyn365 from '@msdyn365-commerce/core';

export interface IFeaturedLayoutItemConfig extends Msdyn365.IModuleConfig {
    categoryLink: ICategoryLinkData;
    bgImage: string;
    heading: string;
    showButton?: boolean;
}

export interface IFeaturedLayoutItemResources {
    resourceKey: string;
}

export interface ICategoryLinkData {
    linkText?: string;
    linkUrl: Msdyn365.ILinkData;
    ariaLabel?: string;
    openInNewTab?: boolean;
}

export interface IFeaturedLayoutItemProps<T> extends Msdyn365.IModule<T> {
    resources: IFeaturedLayoutItemResources;
    config: IFeaturedLayoutItemConfig;
}
