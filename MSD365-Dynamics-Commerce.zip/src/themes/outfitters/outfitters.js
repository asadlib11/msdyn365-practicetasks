import * as React from 'react';
export default () => React.createElement("div", null);
//# sourceMappingURL=slate.js.map