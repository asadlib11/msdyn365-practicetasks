export * from './label';
export * from './label.props';